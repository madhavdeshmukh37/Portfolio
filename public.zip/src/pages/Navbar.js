import React from "react";
import { Link } from "react-router-dom";
import "../App.css";

const Navbar = () => {
  return (
    <nav className="navbar">
      <Link to="/Home">Home</Link>
      <Link to="/education">Education</Link>
      <Link to="/projects">Projects</Link>
      <Link to="/technical">Technical Skills</Link>
       <Link to="/experience">Experience</Link>
    </nav>
  );
};

export default Navbar;
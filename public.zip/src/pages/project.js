import React from "react";
import "../App.css";

const Project = () => {
  return (
    <section className="projects-section">

      <div className="project-heading">
        <h1>Academic Projects</h1>
        <p>
          Electronics and software projects completed during my B.Tech in
          Electronics & Telecommunication Engineering.
        </p>
      </div>

      <div className="projects">

        {/* Project 1 */}

        <div className="project-card">
          <h2>🌱 Smart Automatic Irrigation System</h2>

          <p>
            <strong>Technologies:</strong> Arduino UNO, Soil Moisture Sensor,
            Relay Module, Water Pump, Embedded C
          </p>

          <ul>
            <li>
              Designed an automatic irrigation system to monitor soil moisture
              and control water supply without manual intervention.
            </li>

            <li>
              Used a soil moisture sensor to detect water levels and activate
              the pump automatically when the soil became dry.
            </li>

            <li>
              Improved water conservation by supplying water only when
              required.
            </li>

            <li>
              Gained practical experience in embedded systems, sensor
              interfacing, and automation.
            </li>
          </ul>
        </div>

        {/* Project 2 */}

        <div className="project-card">
          <h2>🚗 Automatic Rain Sensing Wiper System</h2>

          <p>
            <strong>Technologies:</strong> Arduino UNO, Rain Sensor, Servo
            Motor, Embedded C
          </p>

          <ul>
            <li>
              Developed an automatic windshield wiper system that detects
              rainfall and operates the wiper automatically.
            </li>

            <li>
              Controlled the wiper speed based on rain intensity using a rain
              sensor.
            </li>

            <li>
              Improved driving safety by eliminating manual wiper operation
              during rainfall.
            </li>

            <li>
              Enhanced knowledge of sensor integration, motor control, and
              embedded programming.
            </li>
          </ul>
        </div>

        {/* Project 3 */}
        <div className="project-card">
  <h2>🔋 Dual Power Supply</h2>

  <p>
    <strong>Technologies:</strong> Transformer, Bridge Rectifier,
    Filter Capacitor, IC 7812, IC 7912, Voltage Regulator,
    PCB Design, Electronic Components
  </p>

  <ul>
    <li>
      Designed and developed a regulated dual power supply capable of
      providing +12V and -12V DC output for electronic circuits.
    </li>

    <li>
      Converted AC input into stable DC output using a transformer,
      bridge rectifier, filter capacitors, and voltage regulator ICs.
    </li>

    <li>
      Implemented over-voltage protection and ripple reduction to
      ensure reliable power delivery.
    </li>

    <li>
      Gained practical experience in power electronics, PCB assembly,
      circuit testing, soldering, and troubleshooting.
    </li>
  </ul>
</div>



      </div>

    </section>
  );
};

export default Project;
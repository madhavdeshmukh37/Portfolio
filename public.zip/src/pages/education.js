import React from "react";
import "../App.css";

const education = [
  {
    degree: "Bachelor of Technology (B.Tech)",
    branch: "Electronics & Telecommunication Engineering",
    institute: "Dnyanshree Institute of Engineering & Technology, Satara",
    year: "2021 - 2025",
    icon: "🎓",
  },
  {
    degree: "Higher Secondary Certificate (HSC)",
    branch: "Science",
    institute: "Chhatrapati Shahu Academy, Satara",
    year: "2019 - 2021",
    icon: "🏫",
  },
];

const Education = () => {
  return (
    <section className="education-section">

      <div className="education-header">
        <h1>Education</h1>
        <p>
          My academic journey in Electronics, Communication Engineering,
          and Wireless Technologies.
        </p>
      </div>

      <div className="education-container">
        {education.map((item, index) => (
          <div className="education-card" key={index}>

            <div className="education-icon">
              {item.icon}
            </div>

            <div className="education-content">

              <span className="education-year">
                {item.year}
              </span>

              <h2>{item.degree}</h2>

              <h3>{item.branch}</h3>

              <p>{item.institute}</p>

            </div>

          </div>
        ))}
      </div>

    </section>
  );
};

export default Education;
import React from "react";
import "../App.css";

function Home() {
  return (
    <section className="hero">

      <div className="hero-content">

        <p className="hero-tag">
          👋 Hello, I'm
        </p>

        <h1 className="hero-title">
          Madhav Kanta Deshmukh
        </h1>

        <h2 className="hero-role">
          OTA 5G Test Engineer |  Electronics & Telecommunication Engineer
        </h2>

        <p className="hero-description">
          Passionate Electronics & Telecommunication Engineer with hands-on
          experience in <strong> 5G OTA Testing</strong>, RF Measurements,
          Wireless Communication, and Test Validation. Skilled in using RF test
          instruments, analyzing network performance, and troubleshooting
          wireless systems.
        </p>

        <div className="hero-buttons">
          <a
            href="https://github.com/MadhavDeshmukh"
            target="_blank"
            rel="noreferrer"
          >
            GitHub
          </a>

          <a
            href="https://linkedin.com/in/madhav-deshmukh980453271"
            target="_blank"
            rel="noreferrer"
          >
            LinkedIn
          </a>
        </div>

      </div>

      <div className="hero-contact">

        <div className="contact-card">
          <h3>📍 Location</h3>
          <p>Satara, Maharashtra, India</p>
        </div>

        <div className="contact-card">
          <h3>📞 Phone</h3>
          <p>+91 8485068701</p>
        </div>

        <div className="contact-card">
          <h3>📧 Email</h3>
          <p>deshmukhmadhav37@gmail.com</p>
        </div>

      </div>

    </section>
  );
}

export default Home;
import React from "react";
import "../App.css";

const Experience = () => {
  return (
    <section className="experience-section">

      <div className="experience-header">
        <h1>Work Experience</h1>
        <p>
          Hands-on experience in 5G NR OTA Testing, RF Validation, and Wireless Device Testing.
        </p>
      </div>

      <div className="experience-card">

        <div className="experience-top">
          <div>
            <h2>OTA 5G Test Engineer</h2>
            <h3>Jabil</h3>
          </div>

          <span>6 Months (Present)</span>
        </div>

        <p className="experience-location">
          📍 Pune, Maharashtra
        </p>

        <ul>
          <li>
            Performed Over-the-Air (OTA) testing for 5G NR and LTE devices in RF chambers according to standard test procedures.
          </li>

          <li>
            Executed RF validation tests and analyzed key parameters including RSSI, RSRP, RSRQ, SINR, BLER, and EVM.
          </li>

          <li>
            Worked with RF test equipment such as Spectrum Analyzer, Signal Generator, Vector Network Analyzer (VNA), and RF Chamber setups.
          </li>

          <li>
            Supported antenna performance testing, wireless device validation, and RF troubleshooting.
          </li>

          <li>
            Analyzed test logs, documented test results, and prepared reports for engineering teams.
          </li>

          <li>
            Collaborated with cross-functional teams to identify issues and ensure products met quality and customer requirements.
          </li>

        </ul>

      </div>

    </section>
  );
};

export default Experience;
import React from "react";
import "../App.css";

const technicalSkills = [
  {
    icon: "📡",
    title: "OTA Testing",
    skills: [
      "5G OTA Testing",
      "LTE OTA Testing",
      "Ericsson OTA",
      "Antenna Validation",
    ],
  },
  {
    icon: "📶",
    title: "RF Measurements",
    skills: [
      "RSSI",
      "RSRP",
      "RSRQ",
      "SINR",
      "BLER",
      "EVM",
    ],
  },
  {
    icon: "🛰️",
    title: "RF Instruments",
    skills: [
      "Spectrum Analyzer",
      "Signal Generator",
      "Vector Network Analyzer (VNA)",
      "RF Chamber",
    ],
  },
  {
    icon: "💻",
    title: "Programming & Tools",
    skills: [
      "MS Excel",
      "Log Analysis",
      "Test Documentation",
    ],
  },
];

const coreCompetencies = [
  "RF Testing",
  "OTA Validation",
  "Wireless Communication",
  "Antenna Testing",
  "RF Troubleshooting",
  "Test Documentation",
  "Log Analysis",
];

const Technical = () => {
  return (
    <section className="technical-section">

      <div className="technical-header">
        <h1>Technical Skills</h1>

        <p>
          Passionate about <span>5G OTA Testing</span>, RF Measurements,
          Wireless Communication, and Test Automation.
        </p>
      </div>

      <div className="technical-grid">
        {technicalSkills.map((item, index) => (
          <div className="technical-card" key={index}>

            <div className="technical-icon">
              {item.icon}
            </div>

            <h2>{item.title}</h2>

            <div className="skill-list">
              {item.skills.map((skill, i) => (
                <div className="skill-item" key={i}>
                  ✓ {skill}
                </div>
              ))}
            </div>

          </div>
        ))}
      </div>

      <div className="core-section">

        <h2>Core Competencies</h2>

        <div className="core-grid">
          {coreCompetencies.map((item, index) => (
            <div className="core-card" key={index}>
              ⭐ {item}
            </div>
          ))}
        </div>

      </div>

    </section>
  );
};

export default Technical;
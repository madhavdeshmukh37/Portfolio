import React from "react";
import "./App.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Home from "./pages/home";
import Education from "./pages/education";
import Project from "./pages/project";
import Skills from "./pages/Skills";
import Navbar from "./pages/Navbar";
import Technical from "./pages/technical";
import Experience from "./pages/Experience";
function App() {
  return (
    <div className="App">
      <header className="App-header">
       <h2>Welcome to My Portfolio</h2>
      </header>
      <main>
       
          <BrowserRouter>
           <Navbar />
            <Routes>
              <Route path="/home" element={<Home />} />
              <Route path="/education" element={<Education />} />
              <Route path="/projects" element={<Project />} />
              <Route path="/skills" element={<Skills />} />
              <Route path="/technical" element={<Technical />} />
              <Route path="/experience" element={<Experience />} />
            </Routes>
          </BrowserRouter>
      </main>
    </div>
  );
}

export default App;
